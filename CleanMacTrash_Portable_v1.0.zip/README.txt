========================================
   Mac OS 불필요 파일 정리 도구 (포터블)
========================================

이 폴더는 Windows에서 Mac OS 관련 불필요한 파일들을 정리하는 
포터블 도구입니다. USB 드라이브나 다른 위치로 복사해서 
어디서든 사용할 수 있습니다.

📁 포함된 파일:
- CleanMacTrash.exe    : 메인 실행 파일
- clean_trash.bat      : 사용하기 쉬운 배치 파일
- config.json          : 설정 파일
- README.txt           : 이 파일

🚀 빠른 시작:

1. clean_trash.bat을 더블클릭하여 도움말 확인
2. 또는 명령 프롬프트에서:
   clean_trash.bat --list-drives    (드라이브 목록 확인)
   clean_trash.bat --dry-run        (미리보기)
   clean_trash.bat --all-drives     (모든 드라이브 정리)

⚙️ 주요 기능:
- Mac OS 파일 정리 (.DS_Store, ._*, .Spotlight-V100 등)
- Windows 파일 정리 (desktop.ini, Thumbs.db)
- 다중 드라이브 자동 감지
- 안전한 Dry-run 모드
- 상세한 로그 기록

⚠️ 주의사항:
- 관리자 권한이 필요할 수 있습니다
- 중요한 파일은 미리 백업하세요
- 처음 사용 시 --dry-run으로 미리보기하세요

📞 지원:
문제가 있거나 개선 사항이 있으면 개발자에게 문의하세요.

======================================== 